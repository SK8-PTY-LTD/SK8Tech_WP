<?php
/**
 * Product Loop Start
 *
 * @author 		WooThemes
 * @package 	WooCommerce/Templates
 * @version     2.0.0
 */
?>
<div class="clear"></div>
<div class="portfolio noscript small"><div class="galleriffic" data-count="16">
<ul class="products thumbs styled lazy-loading" data-ll-item-delay="0">