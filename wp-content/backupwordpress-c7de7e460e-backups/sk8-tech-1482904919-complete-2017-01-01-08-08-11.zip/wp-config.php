<?php
/**
 * The base configuration for WordPress
 *
 * The wp-config.php creation script uses this file during the
 * installation. You don't have to use the web site, you can
 * copy this file to "wp-config.php" and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * MySQL settings
 * * Secret keys
 * * Database table prefix
 * * ABSPATH
 *
 * @link https://codex.wordpress.org/Editing_wp-config.php
 *
 * @package WordPress
 */

// ** MySQL settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define('DB_NAME', 'skasia_sk8tech');

/** MySQL database username */
define('DB_USER', 'skasia_sk8tech');

/** MySQL database password */
define('DB_PASSWORD', 'SXpSxANTZSjzsB3r');

/** MySQL hostname */
define('DB_HOST', 'localhost');

/** Database Charset to use in creating database tables. */
define('DB_CHARSET', 'utf8mb4');

/** The Database Collate type. Don't change this if in doubt. */
define('DB_COLLATE', '');

/**#@+
 * Authentication Unique Keys and Salts.
 *
 * Change these to different unique phrases!
 * You can generate these using the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}
 * You can change these at any point in time to invalidate all existing cookies. This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define('AUTH_KEY',         '_]#)O@U;CTEeL*T+ipn5B-FZ[;YC^,+5}zyU>(`u;EoPYFZY&L~g*ap(w)/r99H`');
define('SECURE_AUTH_KEY',  '/~t8J&&bG.#,F^H(qyGXpjqzoEE4$xnwkWF+Y__5yb::Jp%+fEU[<:5;WMwR|#OY');
define('LOGGED_IN_KEY',    'WlPi%x[vK}@86c#N`2hl]S8FCoXFe3?6Sx3>sCoA^02Wj<Hs7+d  |>Iin.dD2hy');
define('NONCE_KEY',        '+duDKfOgz_*7XsijW|*-F;lCH]4=*| `wj8gGDl1HXedM4Pel?|]Dhi8iL$DQ&X>');
define('AUTH_SALT',        'Ll6]]_|?e8W{ *Ptd}y*c;6/Sh82CCkkw;E9rLo3J3F+%1?E*=5)VE{EY4df/.j;');
define('SECURE_AUTH_SALT', 'w^#RHb|#ML:T`vOu8a|%y;xJ^Qwtn/%R.s#|Eh3AUj*u,+D9PH6ba|>4+X!x`u7L');
define('LOGGED_IN_SALT',   'P:&&B*cW-l]-Mo!NMyYzk$a0en]GV_n&~c+9cy^-XH?#e@Ya1:{$Gu0%jAf6{w%b');
define('NONCE_SALT',       '/XAls]-41:p_/=6.91Eb4KEC7hc~]Fw%7.gZmlz7Ye|X/l}fpSvhf<tZtb4i5vl]');

/**#@-*/

/**
 * WordPress Database Table prefix.
 *
 * You can have multiple installations in one database if you give each
 * a unique prefix. Only numbers, letters, and underscores please!
 */
$table_prefix  = 'wp_';

/**
 * For developers: WordPress debugging mode.
 *
 * Change this to true to enable the display of notices during development.
 * It is strongly recommended that plugin and theme developers use WP_DEBUG
 * in their development environments.
 *
 * For information on other constants that can be used for debugging,
 * visit the Codex.
 *
 * @link https://codex.wordpress.org/Debugging_in_WordPress
 */
define('WP_DEBUG', true);

/* That's all, stop editing! Happy blogging. */

/** Absolute path to the WordPress directory. */
if ( !defined('ABSPATH') )
	define('ABSPATH', dirname(__FILE__) . '/');

/** Sets up WordPress vars and included files. */
require_once(ABSPATH . 'wp-settings.php');
