<?php
/**
 * Pricing Table | startapp_pricing_table
 *
 * @author 8guild
 */

return array(
	'name'     => __( 'Pricing Table', 'startapp' ),
	'category' => __( 'StartApp', 'startapp' ),
	'icon'     => '',
	'params'   => startapp_vc_map_params( array(), 'startapp_pricing_table' ),
);
